#!/bin/sh
###
### setup
project="$1"
version="$2"
shift 2

profile="ci"
overriden_port="default"
enabled_openrasp="no"
encryption_secret="none"
apollo_cluster="none"
mem="1024m"
upstream_version="$version"
enabled_skywalking="no"
apollo_env="$profile"
base_path="/home/iop-user"
max_gc_age="8"
metaspace_size="64m"
timestamp=$(date +%Y%m%d%H%M%S)

# get args
for arg in $*
do
    if [[ "$arg" =~ ^profile:.+ ]]; then
        profile="${arg//profile:/}"
    elif [[ "$arg" =~ ^overriden_port:.+ ]]; then
        overriden_port="${arg//overriden_port:/}"
    elif [[ "$arg" =~ ^enabled_openrasp:.+ ]]; then
        enabled_openrasp="${arg//enabled_openrasp:/}"
    elif [[ "$arg" =~ ^encryption_secret:.+ ]]; then
        encryption_secret="${arg//encryption_secret:/}"
    elif [[ "$arg" =~ ^apollo_cluster:.+ ]]; then
        apollo_cluster="${arg//apollo_cluster:/}"
    elif [[ "$arg" =~ ^mem:.+ ]]; then
        mem="${arg//mem:/}"
    elif [[ "$arg" =~ ^upstream_version:.+ ]]; then
        upstream_version="${arg//upstream_version:/}"
    elif [[ "$arg" =~ ^enabled_skywalking:.+ ]]; then
        enabled_skywalking="${arg//enabled_skywalking:/}"
    elif [[ "$arg" =~ ^apollo_env:.+ ]]; then
        apollo_env="${arg//apollo_env:/}"
    elif [[ "$arg" =~ ^base_path:.+ ]]; then
        base_path="${arg//base_path:/}"
    elif [[ "$arg" =~ ^max_gc_age:.+ ]]; then
        max_gc_age="${arg//max_gc_age:/}"
    elif [[ "$arg" =~ ^metaspace_size:.+ ]]; then
        metaspace_size="${arg//metaspace_size:/}"
    else
        echo "$arg not support"
        echo "e.g 中括号表示该项可选: [profile:ci] [overriden_port:default] [enabled_openrasp:no] [upstream_version:2.0.0] [encryption_secret:none] [apollo_cluster:none] [mem:512m] [base_path:/home/iop-user] [enabled_skywalking:no] [apollo_env:ci] [max_gc_age:8] [metaspace_size:64m]"
        break
    fi
done

version_path="$base_path/$upstream_version"
echo "project is $project, version is $version, profile is $profile, overriden_port is $overriden_port, 
  enabled_openrasp is $enabled_openrasp, encryption_secret is $encryption_secret, apollo_cluster is $apollo_cluster, base_path is $base_path, 
  mem is $mem, upstream_version is $upstream_version, version_path is $version_path, enabled_skywalking is $enabled_skywalking, apollo_env is $apollo_env,
  max_gc_age is $max_gc_age, metaspace_size is $metaspace_size"

package_name="$project-$version"
log_path="$version_path/jenkins_temp/logs"
log_file="$log_path/$package_name.log"
jar_file="$version_path/jenkins_temp/$package_name.jar"
rasp_path="$version_path/jenkins_temp/scripts/$package_name/rasp-$profile"
skywalking_path="$version_path/jenkins_temp/scripts/$package_name/skywalking-$profile"

if [ -z "$jar_file" ];then
  echo "jar file is not found $package_name..."
  exit 1
fi

echo "package name is: $package_name..."
echo "log file path: $log_file..."
echo "rasp path: $rasp_path..."
echo "starting jar file: $jar_file..."
echo "skywlking path: $skywlking_path..."

if [[ "default" == "$overriden_port" ]];then
  echo "overriden port is not set"
  server_port=""
else
  server_port="--server.port=$overriden_port"
  echo "server port is: $server_port..."
  # open firewall port
  port_is_open=$(sudo firewall-cmd --zone=public --list-ports | grep ${overriden_port})
  if [[ -n ${port_is_open} ]];then
    echo "${overriden_port} alread open"
  else
    echo "${overriden_port} is not open, try open ${overriden_port} port"
    sudo firewall-cmd --add-port=${overriden_port}/tcp --permanent && sudo firewall-cmd --reload
  fi
fi

if [[ "none" == "$apollo_cluster" ]];then
  echo "apollo_cluster is not set"
  choose_cluster=""
else
  choose_cluster="--apollo.cluster=$apollo_cluster"
  echo "choose apollo cluster: $choose_cluster..."
fi

if [[ "no" == "$enabled_openrasp" ]];then
  echo "enabled openrasp is not set"
  rasp_agent=""  
else
  rasp_agent="-javaagent:$rasp_path/rasp.jar"
  echo "need openrasp: $need_openrasp..."
fi

if [[ "none" == "$encryption_secret" ]];then
  echo "encryption secret is not set"
  encryption_secret_param=""
else
  encryption_secret_param="--jasypt.encryptor.password=$encryption_secret"
  echo "configuration encryption secret parameter is $encryption_secret_param"
fi

allocated_mem=$mem
echo "declared memory is $mem... allocated memory is $allocated_mem"

if [[ "none" == "$upstream_version" ]];then
  echo "upstream_version is not set"
  upstream_version_param=""
else
  upstream_version_param="--eureka.instance.metadata-map.upstream_version=$upstream_version"
  echo "configuration upstream_version parameter is $upstream_version_param"
fi

if [[ "no" == "$enabled_skywalking" ]];then
  echo "enabled_skywalking is not set"
  skywalking_agent=""
else
  skywalking_agent="-javaagent:$skywalking_path/skywalking-agent.jar"
  echo "configuration skywalking agent is $skywalking_agent"
fi

mkdir $log_path -p

process_id=$(ps -aef | grep $jar_file | grep -v grep  | grep -v bash | awk '{print $2}')
echo "found existing package: $jar_file, process id is $process_id..."
if [ -z "$process_id" ];then
  echo "not existing service running $jar_file..."
else
  kill -9 $process_id
  echo "killed existing service $process_id..."
fi

cat /dev/null > $log_file

nohup java $rasp_agent $skywalking_agent \
-server \
-Xms$allocated_mem \
-Xmx$allocated_mem \
-XX:MetaspaceSize=$metaspace_size \
-XX:MaxTenuringThreshold=$max_gc_age \
-XX:+DisableExplicitGC \
-XX:+PrintGCDetails \
-XX:+PrintGCDateStamps \
-XX:+PrintGCTimeStamps \
-XX:+PrintHeapAtGC \
-Xloggc:$log_path/$package_name$timestamp'.gc.log' \
-XX:+HeapDumpOnOutOfMemoryError \
-Denv=$apollo_env \
-jar $jar_file --version=$version --activatedProfile=$profile --spring.profiles.active=$profile --basePath=$version_path $server_port $encryption_secret_param $choose_cluster $upstream_version_param >> $log_file 2>&1 &

echo "$log_file"

sleep 3s

a=''

echo "$log_file"

while :
do
  echo 'checking spring boot application...'
  a=`tail -n 500 "$log_file" | grep -e 'Started .* in .* seconds'`
  b=`tail -n 30 "$log_file"`
  echo "$a"
  if [ "$a" != "" ]; then
    echo 'done...'
    exit 0
  else
    echo 'not yet...'
    echo "$b"
  fi
  sleep 3s
done