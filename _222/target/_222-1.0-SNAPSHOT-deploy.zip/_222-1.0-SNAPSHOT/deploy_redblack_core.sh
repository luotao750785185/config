#!/bin/sh

environment=$1
profile=$2
operation=$3

applicationName=$4

eurekaAddress_all=$5 #{dev};{test};{prod}
instanceId_all_A=$6 # {dev1},{dev2};{test1},{test2};{prod1},{prod2}
instanceId_all_B=$7 # {dev1},{dev2};{test1},{test2};{prod1},{prod2}

arr_eurekaAddressId=(${eurekaAddress_all//;/ })
eurekaAddress_dev=${arr_eurekaAddressId[0]}
eurekaAddress_test=${arr_eurekaAddressId[1]}
eurekaAddress_prod=${arr_eurekaAddressId[2]}

arr_instanceId_A=(${instanceId_all_A//;/ })
instanceId_dev_A=${arr_instanceId_A[0]}
instanceId_test_A=${arr_instanceId_A[1]}
instanceId_prod_A=${arr_instanceId_A[2]}

arr_instanceId_B=(${instanceId_all_B//;/ })
instanceId_dev_B=${arr_instanceId_B[0]}
instanceId_test_B=${arr_instanceId_B[1]}
instanceId_prod_B=${arr_instanceId_B[2]}

### preparation - operation
if [ $# -lt 7 ]; then
  echo "parameter error, need 7 parameters, while current have $#..."
  exit 1
fi  

echo "operation input is $operation..."
if [[ $operation == 'on' ]];then
  echo 'on'
  operation='UP'
elif [[ $operation == 'off' ]];then
  echo 'off'
  operation='OUT_OF_SERVICE'
elif [[ $operation == 'down' ]];then
  echo 'down'
  operation='DOWN'
else
  echo 'on|off|down';
  exit 0;
fi

### preparation - environment - profile
echo "environment input is $environment..."
if [[ $environment == 'prod' ]];then
  echo "selected environment is production..."
  eurekaAddress=$eurekaAddress_prod
  if [[ $profile == 'A' ]];then
    instanceId=$instanceId_prod_A
  elif [[ $profile == 'B' ]];then
    instanceId=$instanceId_prod_B
  else
    echo "unknown profile $profile..."
	exit 1
  fi
elif [[ $environment == 'test' ]];then
  echo "selected environment is test..."
  eurekaAddress=$eurekaAddress_test
  if [[ $profile == 'A' ]];then
    instanceId=$instanceId_test_A
  elif [[ $profile == 'B' ]];then
    instanceId=$instanceId_test_B
  else
    echo "unknown profile $profile..."
	exit 1
  fi
elif [[ $environment == 'dev' ]];then
  echo "selected environment is dev..."
  eurekaAddress=$eurekaAddress_dev
  if [[ $profile == 'A' ]];then
    instanceId=$instanceId_dev_A
  elif [[ $profile == 'B' ]];then
    instanceId=$instanceId_dev_B
  else
    echo "unknown profile $profile..."
	exit 1
  fi
else
  echo "unknown environment $environment..."
  exit 1
fi

### execution
echo "instanceId is $instanceId..."
arr_instanceId=(${instanceId//,/ })
for id in ${arr_instanceId[@]}
  do
    echo "eurekaAddress is $eurekaAddress..."
	echo "applicationName is $applicationName..."
	echo "proceeding $id..."
	echo "operation $operation..."
    r=`curl -X PUT -w %{http_code} http://$eurekaAddress/eureka/apps/$applicationName/$id/status?value=$operation`
    if [[ '200' == $r ]];then
      echo "got http status $r, ok!!!"
    else
      echo "ERROR status $r!!!"
      exit 1
    fi
  done
echo "finished..."
exit 0