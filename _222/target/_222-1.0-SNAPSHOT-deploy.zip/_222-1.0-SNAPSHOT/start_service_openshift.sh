#!/bin/sh
###
### setup
project=$1
version=$2
profile=$3
overriden_port=$4
enabled_openrasp=$5
encryption_secret=$6
apollo_cluster=$7
base_path=$8
mem=$9
upstream_version=${10}
enabled_skywalking=${11}

### definition
if [ $# -lt 9 ]; then
  echo "parameter error, need at least 9 parameters, while current have $#..."
  exit 1
fi  
echo "profile is $profile, overriden_port is $overriden_port, enabled_openrasp is $enabled_openrasp
	encryption_secret is $encryption_secret, apollo_cluster is $apollo_cluster, mem is $mem, base_path is $base_path, upstream_version is $upstream_version
  enabled_skywalking is $enabled_skywalking"

#scripts_path="$base_path/scripts"
package_name="$project-$version"
jar_file="$base_path/$package_name.jar"
rasp_path="$base_path/scripts/rasp-$profile"
skywalking_path="$base_path/scripts/skywalking-$profile"

if [ -z "$jar_file" ];then
  echo "jar file is not found $package_name..."
  exit 1
fi

# echo "scripts path is: $scripts_path..."
echo "package name is: $package_name..."
echo "rasp path: $rasp_path..."
echo "starting jar file: $jar_file..."
echo "skywlking path: $skywlking_path..."

#if [ -z "$overriden_port" ];then
if [[ "default" == "$overriden_port" ]];then
  server_port=""
else
  server_port="--server.port=$overriden_port"
fi
echo "server port is: $server_port..."

if [[ "none" == "$apollo_cluster" ]];then
  echo "apollo_cluster is not set"
  choose_cluster=""
else
  choose_cluster="--apollo.cluster=$apollo_cluster"
fi
echo "choose apollo cluster: $choose_cluster..."

if [[ "yes" == "$enabled_openrasp" ]];then
  rasp_agent="-javaagent:$rasp_path/rasp.jar"
else
  echo "openrasp not enabled"
  rasp_agent=""
fi
echo "enabled openrasp: $enabled_openrasp..."
# set encryption secret to encrypt configuration
# if [ -z "$encryption_secret" ];then
if [[ "none" == "$encryption_secret" ]];then
  echo "encryption secret is not set"
  encryption_secret_param=""
else
  encryption_secret_param="--jasypt.encryptor.password=$encryption_secret"
fi
echo "configuration encryption secret parameter is $encryption_secret_param"

allocated_mem=$mem
echo "declared memory is $mem... allocated memory is $allocated_mem"

# set upstream_version
if [[ "none" == "$upstream_version" ]];then
  echo "upstream_version is not set"
  upstream_version_param=""
else
  upstream_version_param="--eureka.instance.metadata-map.upstream_version=$upstream_version"
fi
echo "configuration upstream_version parameter is $upstream_version_param"

# set skywlking
if [[ "yes" == "$enabled_skywalking" ]];then
  skywalking_agent="-javaagent:$skywalking_path/skywalking-agent.jar"
else
  echo "enabled_skywalking is not set"
  skywalking_agent=""
fi
echo "configuration skywalking agent is $skywalking_agent"

java $rasp_agent $skywalking_agent \
-server \
-Xms$allocated_mem \
-Xmx$allocated_mem \
-XX:MetaspaceSize=64m \
-XX:+DisableExplicitGC \
-XX:+PrintGCDetails \
-XX:+PrintGCDateStamps \
-XX:+PrintGCTimeStamps \
-XX:+PrintHeapAtGC \
-Xloggc:$base_path/log/$package_name'.gc.log' \
-Denv=$profile \
-jar $jar_file --version=$version --activatedProfile=$profile --spring.profiles.active=$profile --basePath=$base_path $server_port $encryption_secret_param $choose_cluster $upstream_version_param