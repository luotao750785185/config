#!/bin/sh
### setup
eurekaHost=$1
projectName=$2
instanceIdList=$3
operation=$4 # UP / OUT_OF_SERVICE / DOWN

if [ $# -lt 4 ]; then
  echo "parameter error, need 4 parameters, while current have $#..."
  exit 1
fi  

echo "operation input is $operation..."
if [[ $operation == 'on' ]];then
  echo 'on'
  operation='UP'
elif [[ $operation == 'off' ]];then
  echo 'off'
  operation='OUT_OF_SERVICE'
elif [[ $operation == 'down' ]];then
  echo 'down'
  operation='DOWN'
else
  echo 'on|off|down';
  exit 1;
fi

### execution
echo "instanceId is $instanceId..."
arr_instanceId=(${instanceIdList//,/ })
global_exit_code=0
for id in ${arr_instanceId[@]}
  do
    echo "eurekaHost is $eurekaHost..."
    echo "projectName is $projectName..."
    echo "proceeding $id..."
    echo "operation $operation..."
    echo "curl url http://$eurekaHost/eureka/apps/$projectName/$id/status?value=$operation..."
    r=`curl -X PUT -w %{http_code} http://$eurekaHost/eureka/apps/$projectName/$id/status?value=$operation`
    if [[ '200' == $r ]];then
      echo "got http status $r, ok!!!"
    else
      echo "ERROR status $r!!!"
      global_exit_code=1
    fi
  done
echo "finished..."
exit $global_exit_code
